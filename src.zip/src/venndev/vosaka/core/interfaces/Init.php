<?php

declare(strict_types=1);

namespace venndev\vosaka\core\interfaces;

interface Init
{
    public static function init(): self;
}