<?php

declare(strict_types=1);

namespace venndev\vosaka\utils\sync;

final class CancelFuture
{
    // This class is intentionally left empty.
}